﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RentCarProject.Migrations
{
    /// <inheritdoc />
    public partial class RentCar : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cliente",
                columns: table => new
                {
                    IdClientes = table.Column<int>(type: "int", nullable: true),
                    Nombre = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Cedula = table.Column<int>(type: "int", nullable: true),
                    NoTarjetaCR = table.Column<int>(name: "No.TarjetaCR", type: "int", nullable: true),
                    LimiteCredito = table.Column<int>(type: "int", nullable: true),
                    TipoPersona = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "Devolucion",
                columns: table => new
                {
                    NoRenta = table.Column<int>(name: "No.Renta", type: "int", nullable: true),
                    IdEmpleado = table.Column<int>(type: "int", nullable: true),
                    IdVehiculo = table.Column<int>(type: "int", nullable: true),
                    IdCliente = table.Column<int>(type: "int", nullable: true),
                    FechaDevolucion = table.Column<int>(type: "int", nullable: true),
                    MontoxDia = table.Column<int>(type: "int", nullable: true),
                    CantidadDeDias = table.Column<int>(type: "int", nullable: true),
                    Comentario = table.Column<string>(type: "nchar(10)", fixedLength: true, maxLength: 10, nullable: true),
                    Estado = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "Empleados",
                columns: table => new
                {
                    IdEmpleado = table.Column<int>(type: "int", nullable: true),
                    Nombre = table.Column<string>(type: "nchar(10)", fixedLength: true, maxLength: 10, nullable: true),
                    cedula = table.Column<int>(type: "int", nullable: true),
                    TandaLaboral = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    PorcientoComision = table.Column<int>(type: "int", nullable: true),
                    FechaIngreso = table.Column<int>(type: "int", nullable: true),
                    Estado = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "Inspeccion",
                columns: table => new
                {
                    IdTransaccion = table.Column<int>(type: "int", nullable: true),
                    IdVehiculo = table.Column<int>(type: "int", nullable: true),
                    IdCliente = table.Column<int>(type: "int", nullable: true),
                    Ralladuras = table.Column<string>(type: "nchar(10)", fixedLength: true, maxLength: 10, nullable: true),
                    CantidadCombustible = table.Column<int>(type: "int", nullable: true),
                    GomaRepuesta = table.Column<int>(type: "int", nullable: true),
                    EstadoGomas = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "Marcas",
                columns: table => new
                {
                    IdMarca = table.Column<int>(type: "int", nullable: true),
                    Descripcion = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Estado = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "Modelos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: true),
                    IdMarca = table.Column<int>(type: "int", nullable: true),
                    Descripcion = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Estado = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "Renta",
                columns: table => new
                {
                    NoRenta = table.Column<int>(name: "No.Renta", type: "int", nullable: true),
                    IdEmpleado = table.Column<int>(type: "int", nullable: true),
                    IdVehiculo = table.Column<int>(type: "int", nullable: true),
                    IdCliente = table.Column<int>(type: "int", nullable: true),
                    FechaRenta = table.Column<int>(type: "int", nullable: true),
                    MontoxDia = table.Column<int>(type: "int", nullable: true),
                    CantidadDeDias = table.Column<int>(type: "int", nullable: true),
                    Comentario = table.Column<int>(type: "int", nullable: true),
                    Estado = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "TipoCombustible",
                columns: table => new
                {
                    IdTipoCombustible = table.Column<int>(type: "int", nullable: true),
                    Descripcion = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Estado = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "TiposVehiculos",
                columns: table => new
                {
                    IdTipoVehiculo = table.Column<int>(type: "int", nullable: true),
                    Descripcion = table.Column<int>(type: "int", nullable: true),
                    Estado = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "Vehiculos",
                columns: table => new
                {
                    IdVehiculo = table.Column<int>(type: "int", nullable: true),
                    Descripcion = table.Column<int>(type: "int", nullable: true),
                    NoChasis = table.Column<int>(name: "No.Chasis", type: "int", nullable: true),
                    NoMotor = table.Column<int>(name: "No.Motor", type: "int", nullable: true),
                    NoPlaca = table.Column<int>(name: "No.Placa", type: "int", nullable: true),
                    IdTipoVehiculo = table.Column<int>(type: "int", nullable: true),
                    IdMarca = table.Column<int>(type: "int", nullable: true),
                    IdModelo = table.Column<int>(type: "int", nullable: true),
                    IdTipoCombustible = table.Column<int>(type: "int", nullable: true),
                    Estado = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cliente");

            migrationBuilder.DropTable(
                name: "Devolucion");

            migrationBuilder.DropTable(
                name: "Empleados");

            migrationBuilder.DropTable(
                name: "Inspeccion");

            migrationBuilder.DropTable(
                name: "Marcas");

            migrationBuilder.DropTable(
                name: "Modelos");

            migrationBuilder.DropTable(
                name: "Renta");

            migrationBuilder.DropTable(
                name: "TipoCombustible");

            migrationBuilder.DropTable(
                name: "TiposVehiculos");

            migrationBuilder.DropTable(
                name: "Vehiculos");
        }
    }
}
